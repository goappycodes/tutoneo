<?php

namespace App\Models;

class DominantMemoryForm extends Post
{
    const ID = 16;
}
