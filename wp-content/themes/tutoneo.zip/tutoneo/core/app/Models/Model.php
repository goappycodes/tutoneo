<?php

namespace App\Models;

abstract class Model
{

}