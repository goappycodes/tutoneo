<?php

namespace App\Models;

class ParentQuestionnaireForm extends Post
{
    const ID = 18;
}
