<?php

namespace App\Models;

class ParentUser extends User 
{
    
}