<?php

namespace App\Models;

class StudentQuestionnaireForm extends Post
{
    const ID = 14;
}
