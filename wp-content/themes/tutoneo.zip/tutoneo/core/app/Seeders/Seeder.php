<?php

namespace App\Seeders;

abstract class Seeder
{
    abstract protected static function seed();
}
