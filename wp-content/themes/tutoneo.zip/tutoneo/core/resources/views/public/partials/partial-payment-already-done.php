<div class="container">
    <div class="row">
        <div class="col-12 text-center p-10">
            <h1 class="text-danger"><?php echo __('Invalid Booking!') ?></h1>
            <h3 class="pt-5">
                <?php echo __('You have already paid for this booking.') ?>
            </h3>
            <button class="btn btn-primary mt-5" onclick="history.back()">Go Back</button>
        </div>
    </div>
</div>