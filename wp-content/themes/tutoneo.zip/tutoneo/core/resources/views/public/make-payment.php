<div class="container">
    <div class="row">
        <div class="col-12 text-center p-10">
            <h1 class="text-muted"><?php echo __('Redirecting to checkout.stripe.com...') ?></h1>
        </div>
    </div>
</div>