<div class="container">
    <div class="row">
        <div class="col-12 text-center p-10">
            <h1 class="text-danger"><?php echo __('Invalid Booking!') ?></h1>
            <h3 class="pt-5">
                <?php echo __('The booking you are looking for does not exists!') ?>
            </h3>
            <button class="btn btn-primary mt-5" onclick="history.back()">Go Back</button>
        </div>
    </div>
</div>