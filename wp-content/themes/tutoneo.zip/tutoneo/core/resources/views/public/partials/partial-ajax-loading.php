<?php 

use App\Config\Config;
?>
<div class="ajax-loading" style="display: none;">
    <div class="text-center">
        <img width="250" src="<?php echo Config::IMG_DIR_URI . '/gif/loader.gif'; ?>" alt="loading...">
    </div>
</div>